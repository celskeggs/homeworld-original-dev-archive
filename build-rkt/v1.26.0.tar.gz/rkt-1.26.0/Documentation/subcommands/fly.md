# rkt fly

***This subcommand does not exist yet.***

It will make use of the fly stage1 which is currently in an early phase of development.
More information can be found in the document about [running rkt with the fly stage1][fly].


[fly]: ../running-fly-stage1.md
