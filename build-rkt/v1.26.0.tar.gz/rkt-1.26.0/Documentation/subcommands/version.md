# rkt version

This command prints the rkt version, the appc version rkt is built against, and the Go version and architecture rkt was built with.

## Example

```
$ rkt version
rkt Version: 1.26.0
appc Version: 0.8.10
Go Version: go1.5.3
Go OS/Arch: linux/amd64
