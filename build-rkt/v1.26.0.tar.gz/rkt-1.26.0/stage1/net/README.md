Some network configuration files that are copied in to the stage1's rootfs.

## NOTE:
Due to a small bug in the makefile, if you rename or remove any files here,
you will have to `make clean`.
