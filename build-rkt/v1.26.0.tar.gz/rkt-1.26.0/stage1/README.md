Stage1 build
-------------

Stage1 build is invoked by the parent makefile by calling stage1.mk
read the stage1.mk contents for details
