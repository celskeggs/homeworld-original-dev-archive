This package was copied in from the Kubernetes repo to avoid a cyclic
dependency. These files were taken from master from
github.com/kubernetes/kubernetes at commit hash
b0deb2eb8f4037421077f77cb163dbb4c0a2a9f5.
